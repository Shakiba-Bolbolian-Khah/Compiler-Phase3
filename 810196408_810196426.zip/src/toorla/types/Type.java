package toorla.types;

abstract public class Type {
    public abstract String toString();
    public abstract String typeName();
}
