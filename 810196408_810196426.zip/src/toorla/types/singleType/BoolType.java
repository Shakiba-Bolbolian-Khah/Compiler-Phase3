package toorla.types.singleType;

public class BoolType extends SingleType {
    @Override
    public String toString() {
        return "(BoolType)";
    }
    public String typeName() { return "BoolType"; }
}
