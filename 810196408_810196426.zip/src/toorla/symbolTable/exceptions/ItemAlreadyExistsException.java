package toorla.symbolTable.exceptions;

public class ItemAlreadyExistsException extends Exception {
}
