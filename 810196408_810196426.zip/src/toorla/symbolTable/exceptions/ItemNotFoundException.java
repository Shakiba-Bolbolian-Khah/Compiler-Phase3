package toorla.symbolTable.exceptions;


public class ItemNotFoundException extends Exception {
}
