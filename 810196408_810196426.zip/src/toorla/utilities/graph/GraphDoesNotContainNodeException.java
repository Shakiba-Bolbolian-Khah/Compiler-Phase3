package toorla.utilities.graph;

public class GraphDoesNotContainNodeException extends Exception {
}
