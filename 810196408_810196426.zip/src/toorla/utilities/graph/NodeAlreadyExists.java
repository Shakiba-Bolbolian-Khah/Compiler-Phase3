package toorla.utilities.graph;

public class NodeAlreadyExists extends Exception {
}
